import { Routes } from '@angular/router';
import { ProductsComponent } from './pages/products/products.component';
import { OrdersComponent } from './pages/orders/orders.component';
import { CheckoutComponent } from './pages/checkout/checkout.component';
import { ProfileComponent } from './pages/profile/profile.component';

export const routes: Routes = [

    {path:"products", component:ProductsComponent},
    {path:"orders", component:OrdersComponent},
    {path:"checkout", component:CheckoutComponent},
    {path:"profile", component:ProfileComponent},
    {path:"**", pathMatch:"full", redirectTo:"products"}
];
