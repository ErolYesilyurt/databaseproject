import { Component, inject, OnInit } from '@angular/core';
import { MyService } from '../../services/my.service';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-checkout',
  imports: [],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.scss',
})
export class CheckoutComponent implements OnInit {
  ngOnInit(): void {
    this.myService.getOrderDetails();
  }
  myService = inject(MyService);
  authService = inject(AuthService);
  http = inject(HttpClient);

  apiUrl = 'http://localhost:5027/api/';

  removeFromCheckout(order: any) {
    return this.http
      .post(this.apiUrl + 'remove-from-checkout', {
        orderDetailId: order.orderDetailId}).subscribe();
  }

  checkout() {
    return this.http
      .post<any>(this.apiUrl + 'get-checkout-order-by-customer-id', {
        customerId: this.authService.account.customerId,
      })
      .subscribe((res) => {
        this.http
          .post(this.apiUrl + 'checkout', {
            orderId: res.orderId,
          })
          .subscribe();
      });
  }
}
