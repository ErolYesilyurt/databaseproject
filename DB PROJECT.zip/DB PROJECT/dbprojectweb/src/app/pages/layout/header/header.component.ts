import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-header',
  imports: [RouterLink, FormsModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent {
  authService = inject(AuthService);
  changeDetection = inject(ChangeDetectorRef);

  email: string = '';
  firstName: string = '';
  lastName: string = '';

  login() {
    this.authService.login(this.email).subscribe(() => {
      this.changeDetection.detectChanges();
    });
  }

  register() {
    this.authService.register(this.firstName, this.lastName, this.email);
  }

  logout(){
    this.authService.account = null
    this.changeDetection.detectChanges();

  }
}
