import { Component, inject, OnInit } from '@angular/core';
import { MyService } from '../../services/my.service';

@Component({
  selector: 'app-orders',
  imports: [],
  templateUrl: './orders.component.html',
  styleUrl: './orders.component.scss'
})
export class OrdersComponent implements OnInit {
  ngOnInit(): void {
    this.myService.getOrderDetails();
  }
  myService = inject(MyService);

}
