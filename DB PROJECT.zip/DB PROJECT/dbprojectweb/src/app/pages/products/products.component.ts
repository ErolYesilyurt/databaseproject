import { Component, inject, OnInit } from '@angular/core';
import { MyService } from '../../services/my.service';

@Component({
  selector: 'app-products',
  imports: [],
  templateUrl: './products.component.html',
  styleUrl: './products.component.scss',
})
export class ProductsComponent implements OnInit {
  ngOnInit(): void {
    this.myService.getDumbs().subscribe();
    this.myService.getCategories().subscribe((res) => {
      this.myService.getProducts().subscribe();
    });
  }
  myService = inject(MyService);

  addToCheckout(product: any) {
    this.myService.addToCheckOut(product);
  }
}
