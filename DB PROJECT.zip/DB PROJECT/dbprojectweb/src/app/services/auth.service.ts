import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  http = inject(HttpClient);

  apiUrl = 'http://localhost:5027/api/';

  account:any

  // getAccount() {
  //   return JSON.parse(sessionStorage.getItem('account') ?? '');
  // }

  isLoggedIn() {
    if (this.account) {
      return true;
    }
    return false;
  }

  login(email: string) {
    return this.http.post(this.apiUrl + 'login', {email: email}).pipe(map((data)=>{
        this.account = data;
        return data;
      },
    ));
  }

  register(name: string, lastName: string, email: string) {
    this.http
      .post(this.apiUrl + 'create-customer', {
        firstName: name,
        lastName: lastName,
        email: email,
      })
      .subscribe();
  }

  updateAccount(name: string, lastName: string, email: string) {
    this.http
      .post(this.apiUrl + 'update-customer', {
        firstName: name,
        lastName: lastName,
        email: email,
      })
      .subscribe();
  }
  deleteAccount() {
    let cid = this.account.CustomerId;
    this.http
      .post(this.apiUrl + 'delete-customer', { customerId: cid })
      .subscribe();
  }
}
