import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class MyService {
  http = inject(HttpClient);
  authService = inject(AuthService);

  apiUrl = 'http://localhost:5027/api/';

  categories: any[] = [];
  products: any[] = [];
  bestSelling: any[] = [];
  customers: any[] = [];
  orders: any[] = [];
  orderdetails: any[] = [];

  getProductCategory(product: any) {
    return this.categories.find((e) => e.categoryId === product.fK_CategoryId);
  }

  getCategories() {
    return this.http.post<any[]>(this.apiUrl + 'get-categories', {}).pipe(
      map((data) => {
        this.categories = data;
        return data;
      })
    );
  }

  getProducts() {
    return this.http
      .post<any[]>(this.apiUrl + 'find-products', { searchValue: '' })
      .pipe(
        map((data) => {
          this.products = data;
          return data;
        })
      );
  }

  getBestSelling() {
    return this.http
      .post<any[]>(this.apiUrl + 'get-best-selling-products-from-view', {})
      .pipe(
        map((data) => {
          this.bestSelling = data;
          return data;
        })
      );
  }

  getDumbs() {
    return this.http
      .post<any[]>(this.apiUrl + 'get-most-spending-customers', {})
      .pipe(
        map((data) => {
          this.customers = data;
          return data;
        })
      );
  }

  getOrders() {
    return this.http
      .post<any[]>(this.apiUrl + 'get-orders-by-customer-id', {
        customerId: this.authService.account.customerId,
      })
      .pipe(
        map((data) => {
          this.orders = data;
          return data;
        })
      );
  }

  getOrderDetails() {
    return this.http
      .post<any>(this.apiUrl + 'get-checkout-order-by-customer-id', {
        customerId: this.authService.account.customerId,
      })
      .subscribe((res) => {
        this.http
          .post<any[]>(this.apiUrl + 'get-order-details-by-order-id', {
            orderId: res.orderId,
          })
          .subscribe((data) => {
            this.orderdetails = data;
            return data;
          });
      });
  }

  addToCheckOut(product: any) {
    return this.http
      .post(this.apiUrl + 'add-to-checkout', {
        customerId: this.authService.account.customerId,
        productId: product.productId,
        quantity: 1,
      })
      .subscribe();
  }

  getProductFromOrderDetail(order: any) {
    return this.products.find((e) =>
      e.productId === order.fK_ProductId
    );
  }
}
